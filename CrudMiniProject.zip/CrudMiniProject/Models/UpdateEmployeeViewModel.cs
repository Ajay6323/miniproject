﻿namespace CrudMiniProject.Models
{
   
        public class UpdateEmployeeViewModel
        {
        

        public object Id { get; set; }
        public object Name { get; set; }
        public object Email { get; set; }
        public object Salary { get; set; }
        public object Department { get; set; }
    }
}